//let url = "mongodb://daimingzhong:123456@ds125555.mlab.com:25555/test-1"
let url =  "mongodb://jeffcx:a12345@ds147044.mlab.com:47044/nyucssa-gamenight"
const mongoose = require('mongoose');
mongoose.connect(url);

// define the schema for our user model
var playerSchema = mongoose.Schema({
    playerNum : String,
    team:String,
    refillsLeft : {type:Number, default: 2},
    chips : {type:Number,default:500},
    tournamentsLeft : {type:Number,default:3}
});

// create the model for users and expose it to our app
let playerData = mongoose.model('Player', playerSchema);

/*
playerData.find({}).sort({'chips': -1}).limit(10).exec(function (err, players) {
    if (err) {
        console.log(err);

        return;
    }
    JSON.stringify(players);
    console.log(players);
    
});*/


function CalScore(players){
    let redScore = 0;
    let blueScore = 0;
    for(var i = 0;i<players.length;i++){
        if(players[i].team=="red"){
            redScore += players[i].chips;
        }else if(players[i].team=="blue"){
            blueScore += players[i].chips
        }
       
    }
    return [redScore,blueScore]
}


playerData.find({}).exec(function(err,players){
    if (err) {
        console.log(err);

        return;
    }

    JSON.stringify(players);
    let scores = CalScore(players)

    console.log(scores)
})
