from __future__ import division
import math
def s(x):
	return x**2.5
print(s(9)-s(2)-s(7))
g = float(4.0/15.0)

print(107.701331508*(4/15))